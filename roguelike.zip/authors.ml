let hours_worked = [14; 15; 14]
